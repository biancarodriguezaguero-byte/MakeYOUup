# Make YOU Up 💄
App para cargar catálogos de maquillaje en PDF, extraer productos con IA y guardarlos en Supabase.

---

## Estructura del proyecto

```
makeYouUp/
├── index.html                  ← App completa (HTML + CSS + JS)
├── netlify.toml                ← Configuración de Netlify
├── README.md                   ← Esta guía
└── netlify/
    └── functions/
        └── extraer.js          ← Función serverless (la API key de OpenAI vive acá)
```

---

## Paso 1 · Configurar Supabase

1. Entrá a https://supabase.com y creá una cuenta (es gratis).
2. Creá un nuevo proyecto.
3. Andá a **SQL Editor** y ejecutá este SQL para crear la tabla:

```sql
create table productos (
  id        bigint generated always as identity primary key,
  nombre    text not null,
  tipo      text,
  color     text,
  precio    numeric default 0,
  catalogo  text,
  creado_en timestamptz default now()
);
```

4. Andá a **Project Settings → API** y copiá:
   - **Project URL** → es tu `SUPABASE_URL`
   - **anon public** key → es tu `SUPABASE_KEY`

5. En `index.html`, buscá estas dos líneas y reemplazá los valores:
```js
const SUPABASE_URL = 'REEMPLAZAR_CON_TU_URL_SUPABASE';
const SUPABASE_KEY = 'REEMPLAZAR_CON_TU_ANON_KEY';
```

---

## Paso 2 · Subir a GitHub

1. Creá un repositorio nuevo en https://github.com (puede ser privado).
2. Subí los 4 archivos:
   - `index.html`
   - `netlify.toml`
   - `netlify/functions/extraer.js`
   - `README.md`

> Tip: podés arrastrar los archivos directamente en la interfaz de GitHub.

---

## Paso 3 · Configurar Netlify

1. Entrá a https://netlify.com y creá una cuenta gratuita.
2. Hacé clic en **"Add new site" → "Import an existing project"**.
3. Conectá tu cuenta de GitHub y elegí el repositorio.
4. Netlify detecta automáticamente el `netlify.toml`. Dejá todo por defecto y hacé clic en **Deploy site**.

### ⚠️ Agregar las variables de entorno (MUY IMPORTANTE)

En Netlify andá a:
**Site Settings → Environment Variables → Add variable**

Agregá estas tres variables:

| Nombre          | Valor                        |
|-----------------|------------------------------|
| `OPENAI_KEY`    | tu clave de OpenAI (sk-...)  |
| `SUPABASE_URL`  | URL de tu proyecto Supabase  |
| `SUPABASE_KEY`  | anon key de Supabase         |

> La `OPENAI_KEY` NUNCA va en el código. Solo vive en Netlify.
> Así, aunque alguien vea el código fuente de la página, no puede ver tu clave.

5. Una vez agregadas las variables, volvé a deployar:
   **Deploys → Trigger deploy → Deploy site**

---

## Paso 4 · Probar la app

Tu app va a estar disponible en una URL como:
`https://nombre-random.netlify.app`

Podés cambiar el nombre en: **Site Settings → General → Site name**

### Flujo completo:
1. Subís un PDF de catálogo de maquillaje
2. Hacés clic en **"Extraer productos con IA"**
3. La app manda el texto del PDF a la Netlify Function (servidor)
4. La Function llama a OpenAI con tu API key (de forma segura)
5. Los productos aparecen en una tabla para revisarlos
6. Elegís **Guardar** o **No guardar**
7. En la pestaña **Historial** podés ver todos los catálogos cargados y sus productos

---

## Seguridad: ¿por qué la API key está en el servidor?

```
FORMA INSEGURA ❌:          FORMA SEGURA ✅ (esta app):
                            
Navegador ──── API key ──→  Navegador ──→ Netlify Function ──── API key ──→ OpenAI
             (expuesta!)                   (servidor)          (solo en servidor)
```

Con Netlify Functions, la clave de OpenAI vive únicamente en el servidor de Netlify.
El navegador nunca la ve, aunque alguien inspeccione el código fuente.

---

## Tecnologías usadas

- **HTML + CSS + JavaScript** (vanilla, un solo archivo)
- **PDF.js** — leer texto de PDFs en el navegador
- **OpenAI GPT-4o-mini** — extracción de productos con IA
- **Supabase** — base de datos (tabla `productos`)
- **Netlify** — hosting + Functions serverless (backend seguro)
